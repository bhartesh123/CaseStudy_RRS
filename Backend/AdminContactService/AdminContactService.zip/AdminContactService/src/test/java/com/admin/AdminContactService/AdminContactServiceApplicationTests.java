package com.admin.AdminContactService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminContactServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
